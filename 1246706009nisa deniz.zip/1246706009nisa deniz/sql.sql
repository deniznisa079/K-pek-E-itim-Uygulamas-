-- �nce veritaban�n� olu�tur
CREATE DATABASE kopek_komut_db;
GO

USE kopek_komut_db;
GO

-- 1. Kullan�c�lar Tablosu
CREATE TABLE kullanicilar (
    id INT PRIMARY KEY IDENTITY(1,1),
    kullanici_adi NVARCHAR(50) NOT NULL UNIQUE,
    sifre NVARCHAR(50) NOT NULL,
    ad_soyad NVARCHAR(100),
    email NVARCHAR(100)
);

-- 2. K�pekler Tablosu
CREATE TABLE kopekler (
    id INT PRIMARY KEY IDENTITY(1,1),
    kullanici_id INT FOREIGN KEY REFERENCES kullanicilar(id),
    kopek_adi NVARCHAR(50),
    tur NVARCHAR(50),
    yas INT,
    kayit_tarihi DATETIME DEFAULT GETDATE()
);

-- 3. Komutlar Tablosu
CREATE TABLE komutlar (
    id INT PRIMARY KEY IDENTITY(1,1),
    komut_adi NVARCHAR(50),
    aciklama NVARCHAR(MAX),
    zorluk_seviyesi NVARCHAR(20)
);

-- 4. E�itim Kay�tlar� Tablosu
-- 'not' kelimesi MSSQL'de �zel oldu�u i�in [] i�ine al�nmal�d�r.
CREATE TABLE egitim_kayitlari (
    id INT PRIMARY KEY IDENTITY(1,1),
    kopek_id INT FOREIGN KEY REFERENCES kopekler(id),
    komut_id INT FOREIGN KEY REFERENCES komutlar(id),
    basari_durumu NVARCHAR(50),
    [not] NVARCHAR(MAX), 
    tarih DATETIME DEFAULT GETDATE()
);

-- �rnek komutlar� ekleyelim (Tablolar bo� kalmas�n)
INSERT INTO komutlar (komut_adi, aciklama, zorluk_seviyesi) VALUES 
('Otur', 'K�pe�in arka �zerine oturmas�n� sa�lar', 'Kolay'),
('Gel', '�a�r�ld���nda yan�n�za gelmesini sa�lar', 'Kolay'),
('Pati Ver', 'Sa� veya sol patisini uzatmas�n� sa�lar', 'Orta');